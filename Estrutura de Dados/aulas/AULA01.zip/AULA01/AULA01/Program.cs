﻿Int128 A, B, C, Maior;
// Leia(A)
Console.Write("Entre com valor de A:");
A = Int32.Parse(Console.ReadLine());
//Leia(B)
Console.Write("Entre com valor de B:");
B = Int32.Parse(Console.ReadLine());
//Leia(C)
Console.Write("Entre com valor de C:");
C = Int32.Parse(Console.ReadLine());
//Maior = A
Maior = A;
//Se B>Maior então Maior=B
if (B>Maior) {
    Maior= B;
    Console.WriteLine("B é Maior que Maior");
}
Console.WriteLine("AGORA VAMOS VER O C");
//Se C>Maior então Maior=C
if (C > Maior){
    Maior = C;
}
//Imprimir(Maior)
Console.WriteLine("O Maior número é:" + Maior);

