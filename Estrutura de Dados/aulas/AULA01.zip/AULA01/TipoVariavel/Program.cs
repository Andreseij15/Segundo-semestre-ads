﻿Int16 min = Int16.MinValue;
Int16 max = Int16.MaxValue;
Console.WriteLine(min);
Console.WriteLine(max);

Int32 min32 = Int32.MinValue;
Int32 max32 = Int32.MaxValue;
Console.WriteLine(min32);
Console.WriteLine(max32);

float minF = float.MinValue;
float maxF = float.MaxValue;
Console.WriteLine(minF);
Console.WriteLine(maxF);

Double minD = Double.MinValue;
Double maxD = Double.MaxValue;
Console.WriteLine(minD);
Console.WriteLine(maxD);

min32 = 7;
minF = 7;
Console.WriteLine(min32 / 2);
Console.WriteLine(minF / 2);