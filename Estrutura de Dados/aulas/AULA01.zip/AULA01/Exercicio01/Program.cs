﻿// Dados de Entrada
Double PI, NI, PO;
//Dados de Saída
Double Media;
//Entrada de Dados
Console.Write("Entre com sua nota de NI:");
NI=Double.Parse(Console.ReadLine());
Console.Write("Entre com sua nota de PI:");
PI=Double.Parse(Console.ReadLine());
Console.Write("Entre com sua nota de PO:");
PO=Double.Parse(Console.ReadLine());
//PROCESSAMENTO - Solução do Problema - Cálculo da Média
Media = NI * 0.2 + PI * 0.3 + PO * 0.5;
//Saída - Apresentação do Resultado
Console.WriteLine("Sua média calculada :" + Media);

if (Media >= 6)
{
    Console.WriteLine("Parabéns!!!");
    Console.WriteLine("Você foi aprovado!!");
}
else if (Media>=4)
{
    Console.WriteLine("Foi por pouco!!");
    Console.WriteLine("Fazer exame para tirar 6.0!");
}
else if (Media >= 2)
{
    Console.WriteLine("Precisa estudar mais!!");
    Console.WriteLine("Fazer exame para tirar 7.0!");
}
else
{
    Console.WriteLine("Você foi REPROVADO!!");
    Console.WriteLine("Nos vemos semestre que vem!!");
}