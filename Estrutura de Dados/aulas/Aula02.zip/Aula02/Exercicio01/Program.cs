﻿void imprimirVetor(Int32[] vetor)
{
    for (int i = 0; i < vetor.Length; i++)
    {
        Console.Write(vetor[i] + " | ");
    }
    Console.WriteLine();
}
Int32[] gerarVetor(Int32 tamanho)
{
    Int32[] vetor = new Int32[tamanho];
    Random rnd = new Random();
    for (int i = 0; i < vetor.Length; i++)
    {
        Int32 x = rnd.Next(0, 100);
        vetor[i] = x;
    }
    return vetor;
}

Int32 somarVetor(Int32[] vetor)
{
    Int32 soma = 0;
    for (int i = 0;i < vetor.Length; i++)
    {
        soma += vetor[i]; //soma=soma+vetor[i]
    }
    return soma;
}

Double calcMedia(Int32[] vetor)
{
    Double soma = somarVetor(vetor);
    Double media = soma / vetor.Length;

    return media;

}

const Int32 N = 10;
Int32[] lista = gerarVetor(N);
imprimirVetor(lista);
Int32 soma = somarVetor(lista);
Console.WriteLine("Soma=" + soma);
Double media= calcMedia(lista);
Console.WriteLine("Média=" + media);

Int32[] mes0, mes1;
mes0 = gerarVetor(100);
mes1 = gerarVetor(100);
Double media0 = calcMedia(mes0);
Double media1 = calcMedia(mes1);
Double inflacao = (media1 / media0 - 1) * 100;
Console.WriteLine(media0);
Console.WriteLine(media1);
Console.WriteLine(inflacao);



