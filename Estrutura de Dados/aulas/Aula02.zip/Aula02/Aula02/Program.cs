﻿/*
Double preco0, preco1, preco2,preco3,preco4;
Double media;
Console.Write("Entre com preço do Posto 0:");
preco0=Double.Parse(Console.ReadLine());
Console.Write("Entre com preço do Posto 1:");
preco1 = Double.Parse(Console.ReadLine());
Console.Write("Entre com preço do Posto 2:");
preco2 = Double.Parse(Console.ReadLine());
Console.Write("Entre com preço do Posto 3:");
preco3 = Double.Parse(Console.ReadLine());
Console.Write("Entre com preço do Posto 4:");
preco4 = Double.Parse(Console.ReadLine());
media = (preco0 + preco1 + preco2+preco3+preco4) / 5;
Console.WriteLine(media);*/

Double[] preco = new Double[5];
for (int i = 0; i < preco.Length; i++)
{
    Console.Write("Entre com preço do Posto " + i + " :");
    preco[i] = Double.Parse(Console.ReadLine());
}

for (int i = 0; i < preco.Length; i++)
{
    Console.Write(preco[i] + "|");
}
Console.WriteLine();

Double soma = 0;
for (int i = 0;i < preco.Length; i++)
{
    soma=soma + preco[i];
}
Console.WriteLine("Soma:"+soma);
Double media = soma / preco.Length;
Console.WriteLine("Media:"+media);